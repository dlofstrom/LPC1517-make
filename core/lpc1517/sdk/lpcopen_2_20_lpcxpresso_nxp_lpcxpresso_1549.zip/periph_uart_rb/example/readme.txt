LPC15xx UART ringbuffer/interrupt example

Example description:
--------------------
The UART example shows how to use the UART in interrupt mode with transmit
and receive ring buffers.
To use the example, connect a serial cable to the board's RS232/UART port and
start a terminal program to monitor the port.  The terminal program on the host
PC should be setup for 115200-8-N-1.
Once the example is started, a small message is printed on terminal. Any data
received will be returned back to the caller.

Special connection requirements:
--------------------------------
Need to connect with base board for using RS232/UART port.

Build procedures:
-----------------
Visit the  LPCOpen quickstart guides to get started building LPCOpen projects.
[Link: http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides]

