LPC15XX Virtual Comm port example

Example description:
--------------------
The example shows how to us USBD ROM stack to creates a virtual comm port.

Special connection requirements:
--------------------------------
Connect the USB cable between micro connector on board and to a host.
When connected to Windows host use the .inf included in the project
directory to install the driver. For OSx (Mac) host, no drivers are needed.

Build procedures:
-----------------
Visit the LPCOpen quickstart guides to get started building LPCOpen projects.
[Link: http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides]

