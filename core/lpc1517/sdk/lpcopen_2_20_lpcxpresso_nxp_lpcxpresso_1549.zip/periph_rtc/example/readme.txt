LPC15xx RTC example

Example description:
--------------------
This example shows how to setup and use the RTC and to use the alarm
to wake up the device from a sleep mode.
The board LED will toggle on and off twice at a varying rate based on
varied (changing) wakeup timing. Then the chip will go to sleep. After 4
seconds, the RTC alarm will wakeup the chip and turn on the LED. If you
hook up the serial port to a terminal, you will get messages indicating
what is happening.

Special connection requirements:
--------------------------------
There are no special connection requirements for this example.

Build procedures:
-----------------
Visit the  LPCOpen quickstart guides to get started building LPCOpen projects.
[Link: http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides]

