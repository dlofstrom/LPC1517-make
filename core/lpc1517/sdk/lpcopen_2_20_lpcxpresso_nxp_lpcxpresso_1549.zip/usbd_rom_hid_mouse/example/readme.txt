LPC15XX Mouse example

Example description:
--------------------
The example shows how to us USBD ROM stack to creates a HID mouse.

Special connection requirements:
--------------------------------
The tiny joystick that is surface mounted on the eval board moves the mouse.
Pressing the joystick in causes a left mouse click to happening over USB.
For most OSs, no drivers are needed.

Build procedures:
-----------------
Visit the LPCOpen quickstart guides to get started building LPCOpen projects.
[Link: http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides]

