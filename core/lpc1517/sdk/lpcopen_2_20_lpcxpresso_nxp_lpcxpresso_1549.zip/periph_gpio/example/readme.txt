LPC15xx General Purpose Input/Output example

Example description:
--------------------
The General Purpose Input/Output example demonstrates how to use the GPIO functions
for multiple GPIO pin functions at once. The example will operate on multiple GPIO
pins at once usnig the GPIO direction setup and masked write oeprations.

Special connection requirements:
--------------------------------
There are no special connection requirements for this example.

Build procedures:
-----------------
Visit the  LPCOpen quickstart guides to get started building LPCOpen projects.
[Link: http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides]

