LPC15xx Repetitive Timer example

Example description:
--------------------
The Repetitive Interrupt Timer (RIT) example shows how to use the
RIT. The example sets up a periodic interrupt at a selected time
interval.

Special connection requirements:
--------------------------------
There are no special connection requirements for this example.

Build procedures:
-----------------
Visit the  LPCOpen quickstart guides to get started building LPCOpen projects.
[Link: http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides]

