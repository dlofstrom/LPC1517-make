LPC15xx Grouped GPIO Interrupt example

Example description:
--------------------
The Grouped GPIO interrupt example demonstrates the Grouped GPIO interrupt feature.
This example configures Grouped GPIO interrupt 0 to be invoked when a button is 
pressed by the user. The interrupt toggles the state of an LED. 

Special connection requirements:
--------------------------------
There are no special connection requirements for this example.

Build procedures:
-----------------
Visit the  LPCOpen quickstart guides to get started building LPCOpen projects.
[Link: http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides]

